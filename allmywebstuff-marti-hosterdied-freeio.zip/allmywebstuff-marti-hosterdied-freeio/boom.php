<!DOCTYPE html>
<style>
body {
    background-color: pink;
}
</style>
<body>

 
<title> SMILE</title>
<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR01oi2TRNqc-i_aZQEC00w-bPeqsoYER2FC6IEEO3zQl-znWOg" width="500" height="500">

<?php
echo "xo-xo-xo";
?>

</body>
</html>